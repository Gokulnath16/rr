<?php
include ("db.php");
?>

<form action="" enctype="multipart/form-data" method="post">
<input name="image" type="file"><input name="submit" type="submit" value="Upload">
</form>

<?php 

if(isset($_POST['submit']))
{

  $imageName = $_FILES["image"]["name"];
  $imageData = file_get_contents($_FILES["image"]["tmp_name"]);
  $imageType = $_FILES["image"]["type"];

  if(substr($imageType,0,5)=="image")
  {
     $dbQuery = $conn->prepare("INSERT INTO users (image) VALUES ('$imageData') WHERE id=1");

  }
  else
  {
   echo "only images are allowed";
  } 
}
?>
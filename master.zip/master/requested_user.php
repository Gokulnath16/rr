<?php

session_start();

require_once 'db.php';

try{
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "SELECT username FROM users WHERE horoscope = '' ";

    $query = $conn -> query($sql);

    $query->setFetchMode(PDO::FETCH_ASSOC);

}
catch(PDOException $e)
{
echo "Connection failed: " . $e->getMessage();
}

?>




<html>
    <head>
        <title>Registered user</title>

        <meta name="viewport" content="width=device-width, initial-scale=1">


        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    </head>

    <body>
        <div class="container-fluid">
        
            <table class="table">
                <thead>
                    <tr>
                        <th>username</td>                 
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = $query->fetch()): ?>
                    <tr>
                        <td>
                            <?php echo htmlspecialchars($row['username']) ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>        
    </body>
</html>
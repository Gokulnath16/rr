<?php

if (isset($_POST["submit"])) {
$servername = "localhost";
$username = "root";
$password = "";

try {
//Creating connection for mysql
$conn = new PDO("mysql:host=$servername;dbname=rr", $username, $password);
// set the PDO error mode to exception
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
echo "Connected successfully";

$sql = "INSERT INTO users (username, password, details)
    VALUES ('".$_POST["username"]."', '".$_POST["pass"]."', '".$_POST["deatil"]."')";
    // use exec() because no results are returned

if($conn->query($sql)){
echo "<script> alert('new record created successfully'); </script>";
}
else{
echo "<script> alert('Failed'); </script>";
}

$conn  = null;

}

catch(PDOException $e)
{
echo "Connection failed: " . $e->getMessage();
}
	
}

?>




<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>

<form action="" method="post">
	
	<label>Username : </label>
	<input type="text" name="username" required="required username">
	<br>
	<label>Password : </label>
	<input type="password" name="pass" required="Enter password">
	<br>
	<label>Details : </label>
	<input type="text" name="deatil" required="Enter deatils">
<br>


	<input type="submit" value="submit" name="submit">
</form>

</body>
</html>